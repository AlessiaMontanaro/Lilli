<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="alberi" tilewidth="32" tileheight="32" tilecount="100" columns="10">
 <image source="sRandomWorldItems.png" width="320" height="320"/>
</tileset>
