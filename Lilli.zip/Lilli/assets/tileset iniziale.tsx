<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="tileset iniziale" tilewidth="32" tileheight="32" tilecount="144" columns="12">
 <image source="../../First Asset pack.png" width="384" height="384"/>
</tileset>
