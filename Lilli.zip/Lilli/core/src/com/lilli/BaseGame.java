package com.lilli;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.NinePatch;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.lilli.Schermate.BaseScreen;

import static com.badlogic.gdx.graphics.Color.*;
import static com.badlogic.gdx.graphics.Texture.TextureFilter.Linear;

//questa classe serve per organizzare le schermate durante il gioco
public abstract class BaseGame extends Game {
    //salva i riferimenti al gioco, usato quando viene chiamato il metodo setActiveScreen.
    private static BaseGame game;
    public static Label.LabelStyle labelStyle; //Font e colori
    public static TextButton.TextButtonStyle textButtonStyle;

    //usato quando il gioco viene attivato; salva una reference globale usabile in tutto il gioco.
    public BaseGame() {
        game = this;
    }

    //Usato quando il gioco viene attivato
    public void create() {
        InputMultiplexer im = new InputMultiplexer();
        Gdx.input.setInputProcessor(im);

        //imposto il font dei dialoghi
        FreeTypeFontGenerator fontGenerator = new FreeTypeFontGenerator(Gdx.files.internal("04b_25__.ttf"));
        FreeTypeFontGenerator.FreeTypeFontParameter fontParameters = new FreeTypeFontGenerator.FreeTypeFontParameter();
        fontParameters.size = 48;
        fontParameters.color = BLACK;
        fontParameters.borderWidth = 2;
        fontParameters.borderColor = CYAN;
        fontParameters.borderStraight = true;
        fontParameters.minFilter = Linear;
        fontParameters.magFilter = Linear;

        BitmapFont customFont = fontGenerator.generateFont(fontParameters);
        labelStyle = new Label.LabelStyle();
        labelStyle.font = customFont;

        textButtonStyle = new TextButton.TextButtonStyle();
        Texture buttonTex = new Texture(Gdx.files.internal("button.png"));
        NinePatch buttonPatch = new NinePatch(buttonTex, 24, 24, 24, 24);
        textButtonStyle.up = new NinePatchDrawable(buttonPatch);
        textButtonStyle.font = customFont;
        textButtonStyle.fontColor = GRAY;
    }

    //Usato per cambiare schermo durante il gioco, setta la schermata chiamata.
    public static void setActiveScreen(BaseScreen s) {
        game.setScreen(s);
    }
}