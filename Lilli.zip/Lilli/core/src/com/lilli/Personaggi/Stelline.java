package com.lilli.Personaggi;

import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.lilli.BaseActor;

//classe delle stelle raccoglibili
public class Stelline extends BaseActor {

    public boolean collected;

    public Stelline(float x, float y, Stage s) {

        super(x, y, s);

        //immagine di riferimento delle stelle
        loadTexture("starfish.png");

        //le stelle sono animate: ruotano su se stesse continuamente
        Action spin = Actions.rotateBy(30, 1);
        this.addAction(Actions.forever(spin));

        setBoundaryPolygon(8);

        //le inizializzo non prese
        collected = false;
    }
}
