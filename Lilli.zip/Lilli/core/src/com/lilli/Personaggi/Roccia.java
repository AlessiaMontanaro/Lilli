package com.lilli.Personaggi;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.lilli.BaseActor;

//classe delle rocce collidable
public class Roccia extends BaseActor {
    public Roccia(float x, float y, Stage s) {
        super(x, y, s);
        loadTexture("rock.png");
        setBoundaryPolygon(8);
    }
}