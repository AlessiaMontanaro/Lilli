package com.lilli.Personaggi;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.lilli.BaseActor;

import static com.badlogic.gdx.Gdx.input;

//classe della protagonista del gioco, la lumaca
public class Lumaca extends BaseActor {
    public Lumaca(float x, float y, Stage s) {

        super(x, y, s);

        //Immagini della lumaca nei suoi 3 movimenti mentre va avanti
        String[] filenames = {"lumacaOcchi1.png", "lumacaOcchi2.png", "lumacaOcchi3.png"};

        //Creo un'animazione dalle foto della lumaca. Le metto in successione tra loro
        loadAnimationFromFiles(filenames, 0.2f, true);

        //le velocità di movimento
        setAcceleration(400);
        setMaxSpeed(100);
        setDeceleration(400);

        setBoundaryPolygon(8);
    }

    public void act(float deltaTime) {

        super.act(deltaTime);

        //con la freccia verso sinistra la lumaca va verso sinistra (cioè avanti), muovendosi verso i 180 gradi (lo zero è a sx)
        if (input.isKeyPressed(Input.Keys.LEFT))  accelerateAtAngle(180);
        //con la freccia verso destra la lumaca va verso destra (cioè indietro), muovendosi verso i 0 gradi (lo zero è a sx)
        if (input.isKeyPressed(Input.Keys.RIGHT)) accelerateAtAngle(0);
        //con la freccia verso su la lumaca va su, muovendosi verso i 90 gradi (lo zero è a sx)
        if (input.isKeyPressed(Input.Keys.UP))    accelerateAtAngle(90);
        //con la freccia verso giù la lumaca va giù, muovendosi verso i 270 gradi (lo zero è a sx)
        if (input.isKeyPressed(Input.Keys.DOWN))  accelerateAtAngle(270);

        applyPhysics(deltaTime);

        setAnimationPaused(!isMoving());

        //se mi muovo, vado verso l'angolazione giusta
        if (getSpeed() > 0)
            setRotation(getMotionAngle());

        boundToWorld();
        //allineo la camera alla lumaca; la segue
        alignCamera();
    }
}
