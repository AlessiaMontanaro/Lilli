package com.lilli.Personaggi;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.lilli.BaseActor;

//classe del fuoco che è l'animazione di quando viene presa una stella
public class Fuoco extends BaseActor {

    public Fuoco(float x, float y, Stage s) {
        super(x, y, s);
        //il fuoco viene preso da uno sprite con una riga e 4 colonne
        loadAnimationFromSheet("burning_end_1.png", 1, 4, 0.1f, false);
    }

    public void act(float dt) {
        super.act(dt);

        if (isAnimationFinished())
            remove();
    }
}
