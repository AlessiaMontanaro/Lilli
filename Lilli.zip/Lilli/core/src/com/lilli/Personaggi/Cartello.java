package com.lilli.Personaggi;

import com.badlogic.gdx.scenes.scene2d.Stage;
import com.lilli.BaseActor;

//classe dei cartelli sulla mappa
public class Cartello extends BaseActor {
    private String text;
    private boolean viewing;

    public Cartello(float x, float y, Stage s) {
        super(x, y, s);
        loadTexture("sign.png");
        //lo inizializzo non visibile
        viewing = false;
    }

    public void setText(String t) {
        text = t;
    }

    public String getText() {
        return text;
    }

    public void setViewing(boolean v) {
        viewing = v;
    }

    public boolean isViewing() {
        return viewing;
    }
}
