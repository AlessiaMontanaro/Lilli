package com.lilli;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.ScreenUtils;
import com.lilli.Schermate.MenuScreen;

//classe di inizio, fa partire il gioco rimandando alla classe MenuScreen
public class LilliGame extends BaseGame {

	public void create() {
		super.create();
		setActiveScreen(new MenuScreen());
	}
}