package com.lilli;

import com.badlogic.gdx.scenes.scene2d.Action;
import com.lilli.Personaggi.Dialogo;

//classe che serve per utilizzare insieme le classi Dialogo, SceneSegment e Scene
public class SetTextAction extends Action {

    protected String textToDisplay;

    public SetTextAction(String s) {
        textToDisplay = s;
    }

    public boolean act(float dt) {
        Dialogo db = (Dialogo) target;
        db.setText(textToDisplay);
        return true;
        //azione completata
    }
}