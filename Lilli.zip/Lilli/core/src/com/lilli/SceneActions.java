package com.lilli;

import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.utils.Align;

import static com.lilli.BaseActor.getWorldBounds;

//classe usata durante la storia.
//descrive le transizioni con cui la lumaca entra ed esce dallo schermo
public class SceneActions extends Actions {

    public static Action setText(String s) {
        return new SetTextAction(s);
    }

    public static Action pause() {
        return Actions.forever(Actions.delay(1));
    }

    //transizione di arrivo: da sx al centro
    public static Action moveToScreenCenter(float duration) {
        return Actions.moveToAligned(getWorldBounds().width / 2, 0, Align.bottom, duration);
    }

    //transizione di uscita: dal centro verso dx
    public static Action moveToOutsideRight(float duration) {
        return Actions.moveToAligned(getWorldBounds().width, 0, Align.bottomLeft, duration);
    }
}
