package com.lilli.Schermate;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.scenes.scene2d.Event;
import com.badlogic.gdx.scenes.scene2d.EventListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.lilli.BaseActor;
import com.lilli.BaseGame;
import com.lilli.LilliGame;

import static com.badlogic.gdx.scenes.scene2d.InputEvent.Type.*;

//qui ho il menù, la prima classe visibile nel gioco
public class MenuScreen extends BaseScreen {
    public float audioVolume1;
    public Music inizio;

    public void initialize() {

        //sottofondo musicale
        inizio = Gdx.audio.newMusic(Gdx.files.internal("Raindrop.mp3"));
        audioVolume1 = 1.00f;
        inizio.setLooping(true);
        inizio.setVolume(audioVolume1);
        inizio.play();

        //immagine di sfondo
        BaseActor ocean = new BaseActor(0, 0, mainStage);
        ocean.loadTexture("beach.png");
        ocean.setSize(800, 600);

        //nome del gioco, messo con un'immagine
        BaseActor title = new BaseActor(0, 0, mainStage);
        title.loadTexture("logo2.png");

        //primo pulsante: 'INIZIA', fa partire la storia del gioco (cioè la classe StoryScreen).
        //Quando viene cliccato si stoppa la musica del menù
        TextButton startButton = new TextButton("Inizia", BaseGame.textButtonStyle);
        startButton.addListener(new EventListener() {
            @Override
            public boolean handle(Event e) {
                if (!(e instanceof InputEvent) || !((InputEvent) e).getType().equals(touchDown)) return false;
                LilliGame.setActiveScreen(new StoryScreen());
                inizio.stop();
                return false;
            }
        });

        //secondo pulsante: 'ESCI', fa uscire dal gioco.
        TextButton quitButton = new TextButton("Esci", BaseGame.textButtonStyle);
        quitButton.addListener(new EventListener() {
            @Override
            public boolean handle(Event e) {
                if (!(e instanceof InputEvent) || !((InputEvent) e).getType().equals(touchDown)) return false;
                Gdx.app.exit();
                return false;
            }
        });

        //posiziono il titolo nel centro della schermata
        uiTable.add(title).colspan(2).padBottom(50);
        //posiziono i due pulsanti allineati sotto il titolo (due righe sotto)
        uiTable.row();
        uiTable.add(startButton);
        uiTable.add(quitButton);
    }

    @Override
    public void update(float deltaTime) {
    }

    //imposto che il gioco può partire anche se premo 'invio', e anche in questo caso stoppo la musica del menù e vado alla storia del gioco (classe StoryScreen)
    public boolean keyDown(int keyCode){
        if (Gdx.input.isKeyPressed(Input.Keys.ENTER)){
            LilliGame.setActiveScreen(new StoryScreen());
            inizio.stop();
        }

        //imposto che si può uscire dal gioco anche premendo la barra spaziatrice
        if (Gdx.input.isKeyPressed(Input.Keys.ESCAPE))
            Gdx.app.exit();

        return false;
    }
}
