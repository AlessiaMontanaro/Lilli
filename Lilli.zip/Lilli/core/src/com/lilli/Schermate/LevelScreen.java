package com.lilli.Schermate;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapProperties;
import com.badlogic.gdx.scenes.scene2d.Event;
import com.badlogic.gdx.scenes.scene2d.EventListener;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.lilli.BaseActor;
import com.lilli.BaseGame;
import com.lilli.LilliGame;
import com.lilli.Personaggi.*;
import com.lilli.TilemapActor;

//schermata di gioco con il livello da giocare, si apre dopo la storia (StoryScreen)
public class LevelScreen extends BaseScreen {
    private Lumaca lumaca;
    private boolean win;
    private Label stellaLabel;
    private Dialogo dialogo;
    private float audioVolume;
    private Music instrumental;
    public void initialize() {

        //la mappa del gioco. Sotto imposto i vari oggetti di cui è composta
        TilemapActor tilemapActor = new TilemapActor("map.tmx", mainStage);

        //imposto le stelle
        for (MapObject obj : tilemapActor.getTileList("Starfish")) {
            MapProperties props = obj.getProperties();
            new Stelline((float) props.get("x"), (float) props.get("y"), mainStage);
        }

        //imposto le rocce
        for (MapObject obj : tilemapActor.getTileList("Rock")) {
            MapProperties props = obj.getProperties();
            new Roccia((float) props.get("x"), (float) props.get("y"), mainStage);
        }

        //imposto i cartelli con i loro messaggi
        for (MapObject obj : tilemapActor.getTileList("Sign")) {
            MapProperties props = obj.getProperties();
            Cartello sign = new Cartello((float) props.get("x"), (float) props.get("y"), mainStage);
            sign.setText((String) props.get("message"));
        }

        //imposto lo spazio da dove inizia il gioco, la posizione iniziale della lumaca
        MapObject startPoint = tilemapActor.getRectangleList("Start").get(0);
        MapProperties props = startPoint.getProperties();
        lumaca = new Lumaca((float) props.get("x"), (float) props.get("y"), mainStage);

        //inizializzo la variabile win che mi servirà per visualizzare il messaggio di vittoria
        win = false;

        //creo una label in cui scrivo quante stelle mi mancano alla vittoria
        stellaLabel = new Label("Stelline mancanti:", BaseGame.labelStyle);
        stellaLabel.setColor(Color.CYAN);

        //creo un pulsante per ricominciare la partita
        Button.ButtonStyle buttonStyle = new Button.ButtonStyle();

        Texture buttonTex = new Texture(Gdx.files.internal("undo.png"));
        TextureRegion buttonRegion = new TextureRegion(buttonTex);
        buttonStyle.up = new TextureRegionDrawable(buttonRegion);

        Button restartButton = new Button(buttonStyle);
        restartButton.setColor(Color.CYAN);
        restartButton.addListener(new EventListener() {
            @Override
            public boolean handle(Event e) {
                if (!LevelScreen.this.isTouchDownEvent(e)) return false;

                instrumental.dispose();

                LilliGame.setActiveScreen(new LevelScreen());
                return true;
            }
        });

        //creo un pulsante per togliere/mettere il volume
        Button.ButtonStyle buttonStyle2 = new Button.ButtonStyle();

        Texture buttonTex2 = new Texture(Gdx.files.internal("audio.png"));
        TextureRegion buttonRegion2 = new TextureRegion(buttonTex2);
        buttonStyle2.up = new TextureRegionDrawable(buttonRegion2);

        Button muteButton = new Button(buttonStyle2);
        muteButton.setColor(Color.CYAN);

        muteButton.addListener(new EventListener() {
            @Override
            public boolean handle(Event e) {
                if (!LevelScreen.this.isTouchDownEvent(e)) return false;

                audioVolume = 1 - audioVolume;
                instrumental.setVolume(audioVolume);

                return true;
            }
        });

        //mi distanzio di 10 dal lato superiore dello schermo
        uiTable.pad(10);
        //e in questa posizione metto la label
        uiTable.add(stellaLabel).top();
        //più a sinistra metto i due pulsanti, distanziati dalla label
        uiTable.add().expandX().expandY();
        uiTable.add(muteButton).top();
        uiTable.add(restartButton).top();

        //inizializzo le impostazioni dei cartelli
        dialogo = new Dialogo(0, 0, uiStage);
        dialogo.setBackgroundColor(Color.TAN);
        dialogo.setFontColor(Color.BROWN);
        dialogo.setDialogSize(600, 100);
        dialogo.setFontScale(0.80f);
        dialogo.alignCenter();
        dialogo.setVisible(false);

        //inizializzo dove andrà il dialogo nei cartelli
        uiTable.row();
        uiTable.add(dialogo).colspan(4);

        //musica
        instrumental = Gdx.audio.newMusic(Gdx.files.internal("Riverboat 29.mp3"));
        audioVolume = 1.00f;
        instrumental.setLooping(true);
        instrumental.setVolume(audioVolume);
        instrumental.play();
    }

    public void update(float deltaTime) {

        //Le rocce sono fisiche
        for (BaseActor rockActor : BaseActor.getList(mainStage, "com.lilli.Personaggi.Roccia"))
            lumaca.preventOverlap(rockActor);
        //Le stelline sono fisiche
        for (BaseActor starfishActor : BaseActor.getList(mainStage, "com.lilli.Personaggi.Stelline")) {
            Stelline stelline = (Stelline) starfishActor;
            //ma quando passo sopra una stellina non già presa, la prendo (cioè la metto collected e pulisco la zona)
            if (lumaca.overlaps(stelline) && !stelline.collected) {
                stelline.collected = true;
                stelline.clearActions();
                stelline.addAction(Actions.fadeOut(1));
                stelline.addAction(Actions.after(Actions.removeActor()));
                //quando sparisce la stella, compare l'animazione del fuoco
                Fuoco fuoco = new Fuoco(0, 0, mainStage);
                fuoco.centerAtActor(stelline);
                fuoco.setOpacity(0.25f);
            }
        }

        //metto un messaggio di vittoria quando ho preso tutte le stelle e non ho ancora avuto tale messaggio
        if (BaseActor.count(mainStage, "com.lilli.Personaggi.Stelline") == 0 && !win) {
            win = true;
            BaseActor messaggioVittoria = new BaseActor(0, 0, uiStage);
            messaggioVittoria.loadTexture("vittoria.png");
            messaggioVittoria.centerAtPosition(400, 300);
            messaggioVittoria.setOpacity(0);
            messaggioVittoria.addAction(Actions.delay(1));
            messaggioVittoria.addAction(Actions.after(Actions.fadeIn(1)));
        }

        //contatore di stelline mancanti
        stellaLabel.setText("Stelline mancanti: " + BaseActor.count(mainStage, "com.lilli.Personaggi.Stelline"));

        //cartelli
        for (BaseActor signActor : BaseActor.getList(mainStage, "com.lilli.Personaggi.Cartello")) {
            Cartello cartello = (Cartello) signActor;

            //quando mi avvicino ad un cartello, leggo il contenuto del messaggio (lo faccio grazie alla variabile NearBy che
            //diventa vera quando sono a distanza minore di 4 dal cartello)
            lumaca.preventOverlap(cartello);
            boolean nearby = lumaca.isWithinDistance(4, cartello);

            //cartello visibile
            if (nearby && !cartello.isViewing()) {
                dialogo.setText(cartello.getText());
                dialogo.setVisible(true);
                cartello.setViewing(true);
            }

            //cartello non visibile
            if (cartello.isViewing() && !nearby) {
                dialogo.setText(" ");
                dialogo.setVisible(false);
                cartello.setViewing(false);
            }
        }
    }
}
