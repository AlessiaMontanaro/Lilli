package com.lilli.Schermate;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.lilli.*;
import com.lilli.Personaggi.Dialogo;

//classe usata dopo il menù della classe MenuScreen.
//è la storia del gioco
public class StoryScreen extends BaseScreen {

    Scene scene;
    BaseActor continueKey;
    public float audioVolume2;
    public Music storyMusic;

    public void initialize() {
        //sottofondo musicale
        storyMusic = Gdx.audio.newMusic(Gdx.files.internal("Story music.mp3"));
        audioVolume2 = 1.00f;
        storyMusic.setLooping(true);
        storyMusic.setVolume(audioVolume2);
        storyMusic.play();

        //sfondo schermo
        BaseActor background = new BaseActor(0, 0, mainStage);
        background.loadTexture("Grassy Field Day.png");
        background.setSize(800, 600);
        background.setOpacity(0);
        BaseActor.setWorldBounds(background);

        //imposto l'immagine del protagonista del gioco, che comparirà nella storia
        BaseActor lumaca = new BaseActor(0, 0, mainStage);
        lumaca.loadTexture("lumaca_grande.png");
        lumaca.setPosition(-lumaca.getWidth(), 0);

        //imposto il colore, la dimensione e la posizione dell'immagine del dialogo (classe Dialogo)
        Dialogo Dialogo = new Dialogo(0, 0, uiStage);
        Dialogo.setDialogSize(600, 200);
        Dialogo.setBackgroundColor(new Color(0.6f, 0.6f, 0.8f, 1));
        Dialogo.setFontScale(0.75f);
        Dialogo.setVisible(false);

        //posizione finestra di dialogo
        uiTable.add(Dialogo).expandX().expandY().bottom();

        //imposto l'indicazione su come andare avanti e leggere il prossimo dialogo
        continueKey = new BaseActor(0, 0, uiStage);
        //immagine in cui c'è l'indicazione
        continueKey.loadTexture("press_c.png");
        //dimensione immagine
        continueKey.setSize(50, 50);
        continueKey.setVisible(true);

        //imposto questa immagine in basso a destra della finestra di dialogo
        Dialogo.addActor(continueKey);
        continueKey.setPosition(Dialogo.getWidth() - continueKey.getWidth(), 0);

        scene = new Scene();
        mainStage.addActor(scene);

        //prima lo sfondo della storia viene visualizzata subito
        scene.addSegment(new SceneSegment(background, Actions.fadeIn(1)));
        //poi la lumaca viene visualizzata con una transizione che la porta verso il centro
        scene.addSegment(new SceneSegment(lumaca, SceneActions.moveToScreenCenter(2)));
        //infine mostro il dialogo
        scene.addSegment(new SceneSegment(Dialogo, Actions.show()));

        //primo dialogo
        scene.addSegment(new SceneSegment(Dialogo,
                SceneActions.setText("Qui inizia il gioco con protagonista me. Mi presento: sono Lilli, la super lumaca.")));

        scene.addSegment(new SceneSegment(continueKey, Actions.show()));
        scene.addSegment(new SceneSegment(background, SceneActions.pause()));
        scene.addSegment(new SceneSegment(continueKey, Actions.hide()));

        //secondo dialogo
        scene.addSegment(new SceneSegment(Dialogo,
                SceneActions.setText("Ho vinto il record di migliore trova tesori. Aiutami a mantenerlo, devo prendere tutte le stelle. Conto su di te!")));

        scene.addSegment(new SceneSegment(continueKey, Actions.show()));
        scene.addSegment(new SceneSegment(background, SceneActions.pause()));
        scene.addSegment(new SceneSegment(continueKey, Actions.hide()));

        scene.addSegment(new SceneSegment(Dialogo, Actions.hide()));
        scene.addSegment(new SceneSegment(lumaca, SceneActions.moveToOutsideRight(1)));
        scene.addSegment(new SceneSegment(background, Actions.fadeOut(1)));

        scene.start();
    }

    //quando finisce la storia, parte il livello del gioco (nella classe LevelScreen) e stoppo la musica della storia
    public void update(float deltaTime) {
        if (scene.isSceneFinished()){
            BaseGame.setActiveScreen(new LevelScreen());
            storyMusic.stop();
        }
    }

    //vado avanti nei dialoghi premendo il pulsante C
    public boolean keyDown(int keyCode) {
        if (keyCode == Input.Keys.C && continueKey.isVisible()){
            scene.loadNextSegment();
        }

        return false;
    }
}