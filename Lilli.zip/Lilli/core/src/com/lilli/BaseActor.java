package com.lilli;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.*;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Group;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;

//Estende la funzionalità della classe LibGDX Actor aggiungendo il supporto per trame/animazione,
//poligoni di collisione, movimento, confini del mondo e scorrimento della telecamera.
//La maggior parte degli oggetti di gioco dovrebbe estendere questa classe; gli elenchi di estensioni possono essere
//recuperati per fase e nome della classe.
public class BaseActor extends Group {
    private Animation<TextureRegion> animation;
    private float elapsedTime;
    private boolean animationPaused;

    private Vector2 velocityVec;
    private Vector2 accelerationVec;
    private float acceleration;
    private float maxSpeed;
    private float deceleration;

    private Polygon boundaryPolygon;

    //stores size of game world for all actors
    private static Rectangle worldBounds;

    public BaseActor(float x, float y, Stage s) {
        super();

        setPosition(x, y);
        s.addActor(this);

        //inizializzo le animazioni
        animation = null;
        elapsedTime = 0;
        animationPaused = false;

        //inizializzo le variabili fisiche
        velocityVec = new Vector2(0, 0);
        accelerationVec = new Vector2(0, 0);
        acceleration = 0;
        maxSpeed = 1000;
        deceleration = 0;

        boundaryPolygon = null;
    }

    //Allinea con le coordinate x,y il centro del soggetto alle coordinate di posizione date
    public void centerAtPosition(float x, float y) {
        setPosition(x - getWidth() / 2, y - getHeight() / 2);
    }

    //Riposiziona questo BaseActor in modo che il suo centro sia allineato con il centro dell'altro BaseActor
    public void centerAtActor(BaseActor other) {
        centerAtPosition(other.getX() + other.getWidth() / 2, other.getY() + other.getHeight() / 2);
    }

    //Imposta l'animazione utilizzata durante il rendering di questo soggetto; imposta anche la dimensione del soggetto
    public void setAnimation(Animation<TextureRegion> animation) {
        this.animation = animation;
        TextureRegion textureRegion = this.animation.getKeyFrame(0);
        float regionWidth = textureRegion.getRegionWidth();
        float regionHeight = textureRegion.getRegionHeight();
        setSize(regionWidth, regionHeight);
        setOrigin(regionWidth / 2, regionHeight / 2);

        if (boundaryPolygon == null)
            setBoundaryRectangle();
    }

    //Crea l'animazione da immagini salvate nei file
    public Animation<TextureRegion> loadAnimationFromFiles(String[] fileNames, float frameDuration, boolean loop) {
        int fileCount = fileNames.length;
        Array<TextureRegion> textureArray = new Array<>();

        for (int n = 0; n < fileCount; n++) {
            String fileName = fileNames[n];
            Texture texture = new Texture(Gdx.files.internal(fileName));
            texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
            textureArray.add(new TextureRegion(texture));
        }

        Animation<TextureRegion> animation = new Animation<>(frameDuration, textureArray);
        animation.setPlayMode(Animation.PlayMode.NORMAL);

        if (loop)
            animation.setPlayMode(Animation.PlayMode.LOOP);

        if (this.animation == null)
            setAnimation(animation);

        return animation;
    }

    //Crea l'animazione da un'immagine Sprites
    public Animation<TextureRegion> loadAnimationFromSheet(String fileName, int rows, int cols, float frameDuration, boolean loop) {
        Texture texture = new Texture(Gdx.files.internal(fileName), true);
        texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        int frameWidth = texture.getWidth() / cols;
        int frameHeight = texture.getHeight() / rows;

        TextureRegion[][] temp = TextureRegion.split(texture, frameWidth, frameHeight);

        Array<TextureRegion> textureArray = new Array<>();

        for (int r = 0; r < rows; r++)
            for (int c = 0; c < cols; c++)
                textureArray.add(temp[r][c]);

        Animation<TextureRegion> animation = new Animation<>(frameDuration, textureArray);
        animation.setPlayMode(Animation.PlayMode.NORMAL);

        if (loop)
            animation.setPlayMode(Animation.PlayMode.LOOP);

        if (this.animation == null)
            setAnimation(animation);

        return animation;
    }

    //Metodo per creare l'animazione da una singola foto
    public Animation<TextureRegion> loadTexture(String fileName) {
        String[] fileNames = new String[1];
        fileNames[0] = fileName;
        return loadAnimationFromFiles(fileNames, 1, true);
    }

    //La pausa nelle animazioni
    public void setAnimationPaused(boolean pause) {
        animationPaused = pause;
    }

    //Verifica se l'animazione è completa: lo è se la modalità di riproduzione è normale (non in loop) e il tempo
    //trascorso è maggiore del tempo corrispondente all'ultimo fotogramma.
    public boolean isAnimationFinished() {
        return animation.isAnimationFinished(elapsedTime);
    }

    //Setta la visibilità del soggetto
    public void setOpacity(float opacity) {
        this.getColor().a = opacity;
    }

    //Sotto: Metodi in cui si riconoscono le fisiche di gioco

    //Imposta l'accelerazione di un soggetto
    public void setAcceleration(float acceleration) {
        this.acceleration = acceleration;
    }

    //Imposta il rallentamento di un soggetto, applicata quando non c'è accelerazione
    public void setDeceleration(float deceleration) {
        this.deceleration = deceleration;
    }

    //Imposta la massima velocità di un soggetto
    public void setMaxSpeed(float maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    //Imposta la velocità di movimento (in pixel/secondo) nella direzione corrente.
    //Se la velocità attuale è zero (la direzione non è definita), la direzione sarà impostata su 0 gradi.
     public void setSpeed(float speed) {
        // if length is zero, then assume motion angle is zero degrees
        if (velocityVec.len() == 0)
            velocityVec.set(speed, 0);
        else
            velocityVec.setLength(speed);
    }

    //Calcola la velocità di movimento (in pixels/secondi).
    public float getSpeed() {
        return velocityVec.len();
    }

    //Determina se un oggetto è in movimento, cioè se ha speed > 0
    public boolean isMoving() {
        return (getSpeed() > 0);
    }

    //Calcolo l'angolazione di movimento (in gradi), ottenuto dal vettore velocità.
    //Per allineare l'angolo dell'immagine del soggetto con l'angolo di movimento, uso <code>setRotation( getMotionAngle() )</code>.
     public float getMotionAngle() {
        return velocityVec.angleDeg();
    }

    //Aggiorna il vettore di accelerazione in base all'angolo e al valore memorizzato nel campo di accelerazione.
    //L'accelerazione è calcolata usando il metodo <code>applyPhysics</code>
    public void accelerateAtAngle(float angle) {
        accelerationVec.add(
                new Vector2(acceleration, 0).setAngleDeg(angle));
    }

    //Regola il vettore di velocità in base al vettore di accelerazione, quindi regola la posizione in base al vettore di velocità.
    //Se non si accelera, viene applicato il valore di decelerazione.
    //La velocità è limitata dal valore maxSpeed.
    //Il vettore di accelerazione viene reimpostato su (0,0) alla fine del metodo.
    public void applyPhysics(float deltaTime) {
        //applico l'accelerazione
        velocityVec.add(accelerationVec.x * deltaTime, accelerationVec.y * deltaTime);

        float speed = getSpeed();

        //decelero quando non c'è accelerazione
        if (accelerationVec.len() == 0)
            speed -= deceleration * deltaTime;

        //Tengo la velocità entro i limiti (da zero a maxSpeed)
        speed = MathUtils.clamp(speed, 0, maxSpeed);

        //aggiorno la velocità
        setSpeed(speed);

        //aggiorna la posizione (in base al valore memorizzato nel vettore di velocità)
        moveBy(velocityVec.x * deltaTime, velocityVec.y * deltaTime);

        //resetto l'accelerazione
        accelerationVec.set(0, 0);
    }

   //Sotto: Metodi usati per la collisione dei poligoni sulla mappa

    //Imposta il poligono di COLLISIONE di forma RETTANGOLARE.
    //Questo metodo viene chiamato automaticamente quando viene impostata l'animazione, a condizione che il poligono
    //limite corrente sia nullo.
    public void setBoundaryRectangle() {
        float w = getWidth();
        float h = getHeight();

        float[] vertices = {0, 0, w, 0, w, h, 0, h};
        boundaryPolygon = new Polygon(vertices);
    }

    //Sostituisce il poligono di collisione predefinito (rettangolo) con un poligono a n lati.
    //I vertici del poligono si trovano sull'ellisse contenuta nel rettangolo di delimitazione.
    //Nota: un vertice sarà posizionato nel punto (0,larghezza); apparirà un poligono a 4 lati con l'orientamento di un diamante
    public void setBoundaryPolygon(int numSides) {
        float w = getWidth();
        float h = getHeight();

        float[] vertices = new float[2 * numSides];
        for (int i = 0; i < numSides; i++) {
            float angle = i * 6.28f / numSides;
            // coordinata x
            vertices[2 * i] = w / 2 * MathUtils.cos(angle) + w / 2;
            // coordinata y
            vertices[2 * i + 1] = h / 2 * MathUtils.sin(angle) + h / 2;
        }
        boundaryPolygon = new Polygon(vertices);

    }

    //Restituisce il poligono di delimitazione per questo BaseActor, regolato dalla posizione e dalla rotazione correnti
    //dell'attore.
    public Polygon getBoundaryPolygon() {
        boundaryPolygon.setPosition(getX(), getY());
        boundaryPolygon.setOrigin(getOriginX(), getOriginY());
        boundaryPolygon.setRotation(getRotation());
        boundaryPolygon.setScale(getScaleX(), getScaleY());
        return boundaryPolygon;
    }

    //Determina se questo BaseActor si sovrappone ad altri BaseActor (in base ai poligoni di collisione).
    public boolean overlaps(BaseActor other) {
        Polygon currentPoly = this.getBoundaryPolygon();
        Polygon otherPoly = other.getBoundaryPolygon();

        //test iniziale per verificare la performance
        if (!currentPoly.getBoundingRectangle().overlaps(otherPoly.getBoundingRectangle()))
            return false;

        return Intersector.overlapConvexPolygons(currentPoly, otherPoly);
    }

    //Implemento un comportamento "solido":
    //in caso di sovrapposizione, allontana questo BaseActor dall'altro BaseActor finché non ci sono sovrapposizioni.
    public Vector2 preventOverlap(BaseActor other) {
        Polygon currentPoly = this.getBoundaryPolygon();
        Polygon otherPoly = other.getBoundaryPolygon();

        //test iniziale per verificare la performance
        if (!currentPoly.getBoundingRectangle().overlaps(otherPoly.getBoundingRectangle()))
            return null;

        Intersector.MinimumTranslationVector mtv = new Intersector.MinimumTranslationVector();
        boolean polygonOverlap = Intersector.overlapConvexPolygons(currentPoly, otherPoly, mtv);

        if (!polygonOverlap)
            return null;

        this.moveBy(mtv.normal.x * mtv.depth, mtv.normal.y * mtv.depth);
        return mtv.normal;
    }

    //Determina se questo BaseActor è vicino ad altri BaseActor (in base ai poligoni di collisione).
    public boolean isWithinDistance(float distance, BaseActor other) {
        Polygon currentPoly = this.getBoundaryPolygon();
        float scaleX = (this.getWidth() + 2 * distance) / this.getWidth();
        float scaleY = (this.getHeight() + 2 * distance) / this.getHeight();
        currentPoly.setScale(scaleX, scaleY);

        Polygon otherPoly = other.getBoundaryPolygon();

        //test iniziale per migliorare le prestazioni
        if (!currentPoly.getBoundingRectangle().overlaps(otherPoly.getBoundingRectangle()))
            return false;

        return Intersector.overlapConvexPolygons(currentPoly, otherPoly);
    }

    //Imposta le dimensioni del mondo da utilizzare con i metodi boundToWorld() e scrollTo().
    public static void setWorldBounds(float width, float height) {
        worldBounds = new Rectangle(0, 0, width, height);
    }

    //Imposto le dimensioni del mondo da utilizzare con i metodi boundToWorld() e scrollTo().
    public static void setWorldBounds(BaseActor referenceActor) {
        setWorldBounds(referenceActor.getWidth(), referenceActor.getHeight());
    }

    //Ottengo le dimensioni del mondo (mappa)
    public static Rectangle getWorldBounds() {
        return worldBounds;
    }

    //Se un bordo di un oggetto si sposta oltre i limiti del mondo, regolo la sua posizione per mantenerlo completamente
    //sullo schermo.
    public void boundToWorld() {
        if (getX() < 0)
            setX(0);
        if (getX() + getWidth() > worldBounds.width)
            setX(worldBounds.width - getWidth());
        if (getY() < 0)
            setY(0);
        if (getY() + getHeight() > worldBounds.height)
            setY(worldBounds.height - getHeight());
    }

    //Centra la telecamera su questo oggetto, mantenendo il campo visivo della telecamera completamente entro i confini del mondo.
    public void alignCamera() {
        Camera cam = this.getStage().getCamera();
        Viewport v = this.getStage().getViewport();

        //centra la camera sul soggetto
        cam.position.set(this.getX() + this.getOriginX(), this.getY() + this.getOriginY(), 0);

        // bound camera to layout
        cam.position.x = MathUtils.clamp(cam.position.x, cam.viewportWidth / 2, worldBounds.width - cam.viewportWidth / 2);
        cam.position.y = MathUtils.clamp(cam.position.y, cam.viewportHeight / 2, worldBounds.height - cam.viewportHeight / 2);
        cam.update();
    }

    //Qui sotto ci sono i metodi delle istanze (GetList e Count)

    //Recupera un elenco di tutte le istanze dell'oggetto dalla fase specificata con il nome di classe specificato o la cui classe estende la classe con il nome specificato.
    //Se non esistono istanze, restituisce un elenco vuoto.
    //Utile quando si codificano interazioni tra diversi tipi di oggetti di gioco nel metodo di aggiornamento.
    public static ArrayList<BaseActor> getList(Stage stage, String className) {

        ArrayList<BaseActor> list = new ArrayList<>();

        Class theClass = null;

        try {
            theClass = Class.forName(className);
        } catch (Exception error) {
            error.printStackTrace();
        }

        for (Actor a : stage.getActors()) {
            if (theClass.isInstance(a))
                list.add((BaseActor) a);
        }

        return list;
    }

    //Restituisce il numero di istanze di una determinata classe (che estende BaseActor).
    public static int count(Stage stage, String className) {
        return getList(stage, className).size();
    }

    //Qui sotto ci sono i metodi Actor: act e draw
    //Elabora tutte le Azioni e il relativo codice per questo oggetto; chiamato automaticamente dal metodo act nella
    //classe Stage.
    public void act(float deltaTime) {
        super.act(deltaTime);

        if (!animationPaused)
            elapsedTime += deltaTime;
    }

    //Disegna il fotogramma corrente dell'animazione; chiamato automaticamente dal metodo draw nella classe Stage.
    //Se è stato impostato il colore, l'immagine sarà colorata di quel colore
    //Se non è stata impostata alcuna animazione o se l'oggetto è invisibile, non verrà disegnato nulla.
    public void draw(Batch batch, float parentAlpha) {
        //applica l'effetto colorato
        Color c = getColor();
        batch.setColor(c.r, c.g, c.b, c.a);

        if (animation != null && isVisible())
            batch.draw(animation.getKeyFrame(elapsedTime),
                    getX(), getY(), getOriginX(), getOriginY(),
                    getWidth(), getHeight(), getScaleX(), getScaleY(), getRotation());

        super.draw(batch, parentAlpha);
    }
}

